const mongoose = require('mongoose');
mongoose.connect("mongodb://localhost:27017/BMS");

const express = require('express');
const app = express();

const isBlog = require('./middleware/isBlog');
app.use(isBlog.is_Blog);//redirect setup blog page

//admin
const adminRoute = require('./routers/adminRoute');
app.use('/',adminRoute);
//user
const userRoute = require('./routers/userRoute');
app.use('/',userRoute);
//blog
const blogRoute = require('./routers/blogRoute');
app.use('/',blogRoute);

app.listen(3000,(req,res)=>{
    console.log('server running on 3000 port')  
});
