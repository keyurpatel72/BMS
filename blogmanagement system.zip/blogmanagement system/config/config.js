const secret = 'secretofblog';

module.exports={secret}