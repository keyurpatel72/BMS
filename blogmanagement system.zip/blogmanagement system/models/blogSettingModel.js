const mongoose = require('mongoose');

const blogSettingSchema = mongoose.Schema({
    title:{
        type:String,
    },
    blogImage:{
        type:String,
        require:true
    },
    description:{
        type:String,
        require:true
    }
});
module.exports = mongoose.model('BlogSetting',blogSettingSchema);