const express = require('express');
const userRoute =express(); 

const bodyParser = require('body-parser');
userRoute.use(bodyParser.json());
userRoute.use(bodyParser.urlencoded({ extended: false }));

const session = require('express-session');
const config = require('../config/config');

const UserController = require('../controllers/userController');

userRoute.use(session({secret:config.secret}))


userRoute.set('view engine', 'ejs');
userRoute.set('views','./views');



userRoute.get('/login',UserController.login);
userRoute.post('/login',UserController.postlogin);
userRoute.get('/profile',UserController.profile);




module.exports = userRoute;