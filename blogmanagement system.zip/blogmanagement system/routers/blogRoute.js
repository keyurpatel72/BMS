const express = require('express');
const blogRoute =express(); 

const bodyParser = require('body-parser');
blogRoute.use(bodyParser.json());

const BlogController = require('../controllers/blogController');

blogRoute.use(bodyParser.urlencoded({ extended: false }));

blogRoute.use(express.static('public'));

blogRoute.set('view engine', 'ejs');
blogRoute.set('views','./views');

blogRoute.get('/blogs',BlogController.blogs);
blogRoute.get('/post/:id',BlogController.loadPost);


module.exports = blogRoute;