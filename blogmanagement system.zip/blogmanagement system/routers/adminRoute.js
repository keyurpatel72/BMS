const express = require('express');
const adminRoute =express(); 
const bodyParser = require('body-parser');

const AdminController = require('../controllers/adminController');

adminRoute.use(bodyParser.json());
adminRoute.use(bodyParser.urlencoded({ extended: false }));

adminRoute.set('view engine', 'ejs');
adminRoute.set('views','./views');

const multer = require('multer');
const path = require('path');

adminRoute.use(express.static('public'));
const storage = multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,path.join(__dirname,'../public/image'))
    },
    filename: function(req, file, cb) {
        cb(null, Date.now() + "-" + file.originalname);
    }
});
const upload = multer({storage:storage});

//adminRoute.get('/login',AdminController.login);
adminRoute.get('/blog-setup',AdminController.blogSetup);
adminRoute.post('/blog-setup',upload.single('blogImage'),AdminController.blogSetupSave);
adminRoute.get('/dashboard',AdminController.dashboard);
adminRoute.get('/createPost',AdminController.createpost);
adminRoute.post('/createPost',AdminController.createdPost);

module.exports = adminRoute;