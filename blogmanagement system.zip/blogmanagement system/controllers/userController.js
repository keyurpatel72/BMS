const User = require('../models/userModel');
const bcrypt = require('bcrypt');


const login = async(req,res)=>{
    try {
    res.render('login');        
    } catch (error) {
        console.log(error.message)
    }
}
const postlogin = async(req,res)=>{
    try {
        const email = req.body.email;
        const password = req.body.password;
        console.log(password,'psw');
        const UserData = await User.findOne({email:email});
        console.log(UserData.password,"upw")
        if (UserData) {
            const passwordMatch = await  bcrypt.compare(password,UserData.password);
            console.log(passwordMatch,"pm2")
            if (passwordMatch) {
                    console.log(passwordMatch,"pm");

                req.session.user_id = UserData._id;
                console.log(req.session.user_id,"usd");
                req.session.is_admin = UserData.is_admin;
                console.log(req.session.is_admin,"admin")
                if (UserData.is_admin == 1) {
                    res.redirect('/dashboard');
                } else {
                    res.redirect('/profile');
                }
            } else {
            res.render('login',{message:'email  incorrect'});
            }
        } else {
            res.render('login',{message:' password incorrect'});
        }

    } catch (error) {
        console.log(error.message)
    }
}
const profile = async (req,res)=>{
    try {
        res.render('blog')
    } catch (error) {
        console.log(error.message);
    }
}


module.exports = {
    login,
    postlogin,
    profile
}

