const BlogSetting = require('../models/blogSettingModel');
const User = require('../models/userModel');
const Post = require('../models/postModel');
const bcrypt = require('bcrypt');

const securePassword = async(password)=>{
    try {
        const passwordMatch = await  bcrypt.hash(password,12);
        return passwordMatch;
    } catch (error) {
        console.log(error.message);
    }
}

const login = async(req,res)=>{
    res.send('login hear');
   // res.render('login'); 
}



const blogTwo = async(req,res)=>{
    res.send('Blog 2');
}

const blogSetup = async (req,res)=>{
    try {
        var blogSetting = await BlogSetting.find({});
        if (blogSetting.length>0) {
            res.redirect('login');
        } else {
            res.render('blogSetup')
        }
    } catch (error) {
        console.log(error.message);
    }
}
const blogSetupSave = async(req,res)=>{
    try {
    const title = req.body.title;
    const blogImage = req.file.filename;
    const description = req.body.description;
    const name = req.body.name;
    const email = req.body.email;
    //const password = req.body.password;
    const password = await securePassword(req.body.password);
    const blogSetting = new BlogSetting({
        title:title,
        blogImage:blogImage,
        description:description
    });  
     await blogSetting.save();
    const user = new User({
        name:name,
        email:email,
        password:password,
        is_admin:1
    });
    const UserData = await user.save();
    if (UserData) {
        res.redirect('/login');
    } else {
        res.render('blogSetup',{message:'Blog is not proparly seetup!'});
    }

    } catch (error) {
        console.log(error.message);
    }
}
const dashboard = async (req,res)=>{
    try {
        res.render('admin/dashboard')
    } catch (error) {
        console.log(error.message);
    }
}
const createpost = async(req,res)=>{
    try {
        res.render('admin/postmaster');
    } catch (error) {
        console.log(error.message);
    }
}
const createdPost = async(req,res)=>{
    try {
        const title = req.body.title;
        const content = req.body.content;

        const post = new Post({
            title,    
            content
        });
        const Postdata = await post.save();
    if (Postdata) {
        res.redirect('dashboard');
    } else {
        res.render('admin/postmaster',{message:'Blog is not proparly seetup!'});
    }
    } catch (error) {
        console.log(error.length);
    }
}
module.exports={
    login,
    blogSetup,
    blogSetupSave,
    dashboard,
    createpost,
    createdPost
}